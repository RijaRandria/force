<?php

use App\Controllers\HomeController;
use App\Controllers\VehiculesController;
use App\Controllers\ForceController;
use App\Controllers\ForceinsertController;
use App\Controllers\ForcenewController;
use App\Controllers\ForcemodifController;
use App\Controllers\BlogController;
use App\Controllers\ArticleController;
use App\Controllers\UserController;
use App\Controllers\ImagesController;

$app->get('/login',                             UserController::class.':Authentification')          ->setName('authentification');
$app->post('/login',                            UserController::class.':VerifAuth')                 ->setName('verifauth');
$app->get('/changepwd',                         UserController::class.':changepwd')                 ->setName('changepwd');
$app->get('/deconnexion',                       UserController::class.':Logout')                    ->setName('deconnecte');
$app->get('/session',                           UserController::class.':Session')                   ->setName('session');
$app->get('/droitinsuffisant',                  UserController::class.':DroitInsuffisant')          ->setName('droitinsuffisant');

$app->get('/',                                  ForceController::class. ':accueil')                 ->setName('home');

// Route protégée exemple permettant de charger une image ou un fichier PDF en dehors de public
$app->group('/images', function() {
  $this->get('/charge/{nom}',                   ImagesController::class.':Charge')                  ->setName('chargeimage');
  $this->get('/chargepdf/{nom}',                ImagesController::class.':ChargePDF')               ->setName('chargepdf');
  $this->get('/ousuisje',                       ImagesController::class.':OuSuisJe')                ->setName('ouisuisje');
})->add($container->get('auth'));

// Route protégée permettant de créer des usagers et créer les saisies table
$app->group('/user', function() {
  $this->get('/liste',                          UserController::class.':Liste')                     ->setName('listeuser');
  $this->get('/DocList',                        UserController::class.':DocList')                   ->setName('DocList');
  $this->get('/permis',                         UserController::class.':permis')                    ->setName('permis');
  $this->get('/formation',                      UserController::class.':formation')                 ->setName('formation');
  $this->get('/locomotion',                     UserController::class.':locomotion')                ->setName('locomotion');
  $this->get('/etudes',                         UserController::class.':etudes')                    ->setName('etudes');
  $this->get('/situation',                      UserController::class.':situation')                 ->setName('situation');
  $this->get('/ressources',                     UserController::class.':ressources')                ->setName('ressources');
  $this->get('/pieceList',                      UserController::class.':pieceList')                 ->setName('pieceList');
  $this->get('/typesortie',                     UserController::class.':typesortie')                ->setName('typesortie');
  $this->get('/detailsortie',                   UserController::class.':detailsortie')              ->setName('detailsortie');
  $this->get('/motifsortie',                    UserController::class.':motifsortie')               ->setName('motifsortie');
  $this->get('/typedemarche',                   UserController::class.':typedemarche')              ->setName('typedemarche');
  $this->get('/detaildemarche',                 UserController::class.':detaildemarche')            ->setName('detaildemarche');
  $this->get('/detailtypedemarche',             UserController::class.':detailtypedemarche')        ->setName('detailtypedemarche');
  $this->get('/presence',                       UserController::class.':presence')                  ->setName('presence');
  $this->get('/ajouter',                        UserController::class.':FormAjout')                 ->setName('formajoutuser');
  $this->post('/ajouter',                       UserController::class.':Ajout')                     ->setName('ajouteruser');
})->add($container->get('authadmin'));
$app->group('/user', function() {
  $this->get('/Diagnostic',                     UserController::class.':Diagnostic')                ->setName('Diagnostic');
})->add($container->get('auth'));

// Route permettant de changer mot de passe
$app->group('/user', function() {
    $this->post('/changepwd',                   UserController::class.':changepwd')                 ->setName('changepwd');
    $this->post('/modifpwd',                    UserController::class.':modifpwd')                  ->setName('modifpwd');
})->add($container->get('auth'));


$app->group('/Force', function ()  {

  $this->get('/twig',                          VehiculesController::class. ':TestPDO')              ->setName('pdo');
  $this->get('/vide',                          VehiculesController::class. ':Vide')                 ->setName('vide');
  $this->get('/salarie',                       ForceController::class. ':salarie')                  ->setName('salarie');
  $this->get('/lieu',                          ForceController::class. ':lieu')                     ->setName('lieu');
  $this->get('/societe',                       ForceController::class. ':societe')                  ->setName('societe');
  $this->get('/suivi',                         ForceController::class. ':suivi')                    ->setName('suivi');
  $this->get('/suivisalarie/{idsalarie}',      ForceController::class. ':suivisalarie')             ->setName('suivisalarie');
  $this->get('/suivisalarie',                  ForceController::class. ':suivisalarie')             ->setName('suivisalarie');
  $this->get('/entretiensalarie/{idsalarie}',  ForceController::class. ':entretiensalarie')         ->setName('entretiensalarie');
  $this->get('/demarchesalarie/{idsalarie}',   ForceController::class. ':demarchesalarie')          ->setName('demarchesalarie');
  $this->get('/entretiensalarie',              ForceController::class. ':entretiensalarie')         ->setName('entretiensalarie');
  $this->get('/demarchesalarie',               ForceController::class. ':demarchesalarie')          ->setName('demarchesalarie');
  $this->get('/diagnosticsalarie/{idsalarie}', ForceController::class. ':diagnosticsalarie')        ->setName('diagnosticsalarie');
  $this->get('/diagnosticsalarie',             ForceController::class. ':diagnosticsalarie')        ->setName('diagnosticsalarie');
  $this->get('/salariechantier/{idlieu}',      ForceController::class. ':salariechantier')          ->setName('salariechantier');
  $this->get('/salariechantier',               ForceController::class. ':salariechantier')          ->setName('salariechantier');
  $this->get('/newdiag',                       ForceController::class. ':newdiag')                  ->setName('newdiag');
  $this->get('/pmsmpquery',                    ForceController::class. ':pmsmpquery')               ->setName('pmsmpquery');
  $this->post('/insertentretien',              ForceController::class. ':insertentretien')          ->setName('insertentretien');
  $this->post('/insertsuivi',                  ForceController::class. ':insertsuivi')              ->setName('insertsuivi');
  $this->post('/insertdiagnostic',             ForceController::class. ':insertdiagnostic')         ->setName('insertdiagnostic');
  $this->post('/insertdemarchesalarie',        ForceController::class. ':insertdemarchesalarie')    ->setName('insertdemarchesalarie');
  $this->post('/insertdiag',                   ForceController::class. ':insertdiag')               ->setName('insertdiag');
  $this->post('/search',                       ForceController::class. ':Search')                   ->setName('recherche');
  $this->post('/freinsalarie',                 ForceController::class. ':freinsalarie')             ->setName('freinsalarie');
  $this->post('/trisociete',                   ForceController::class. ':trisociete')               ->setName('trisociete')   ;

})->add($container->get('auth'));

$app->group('/Force', function ()  {

  $this->post('/insertsal',                    ForceController::class. ':insertsal')              ->setName('insertsal');
  $this->post('/updatesal',                    ForceController::class. ':updatesal')              ->setName('updatesal');
  $this->post('/insertsortiesal',              ForceController::class. ':insertsortiesal')        ->setName('insertsortiesal');
  $this->post('/insertchantier',               ForceController::class. ':insertchantier')         ->setName('insertchantier');
  $this->post('/insertdoc',                    ForceController::class. ':insertdoc')              ->setName('insertdoc');
  $this->post('/insertpresence',               ForceController::class. ':insertpresence')         ->setName('insertpresence');
  $this->post('/insertpermis',                 ForceController::class. ':insertpermis')           ->setName('insertpermis');
  $this->post('/insertsortie',                 ForceController::class. ':insertsortie')           ->setName('insertsortie');
  $this->post('/insertmotif',                  ForceController::class. ':insertmotif')            ->setName('insertmotif');
  $this->post('/insertdetailsortie',           ForceController::class. ':insertdetailsortie')     ->setName('insertdetailsortie');
  $this->post('/insertdetaildemarche',         ForceController::class. ':insertdetaildemarche')   ->setName('insertdetaildemarche');
  $this->post('/insertdetailtypedemarche',     ForceController::class. ':insertdetailtypedemarche')->setName('insertdetailtypedemarche');
  $this->post('/insertformation',              ForceController::class. ':insertformation')        ->setName('insertformation');
  $this->post('/insertlocomotion',             ForceController::class. ':insertlocomotion')       ->setName('insertlocomotion');
  $this->post('/insertetudes',                 ForceController::class. ':insertetudes')           ->setName('insertetudes');
  $this->post('/insertsituation',              ForceController::class. ':insertsituation')        ->setName('insertsituation');
  $this->post('/insertressources',             ForceController::class. ':insertressources')       ->setName('insertressources');
  $this->post('/insertrenouv',                 ForceController::class. ':insertrenouv')           ->setName('insertrenouv');
  $this->post('/inserttitre',                  ForceController::class. ':inserttitre')            ->setName('inserttitre');
  $this->post('/insertcqpchantier',            ForceController::class. ':insertcqpchantier')      ->setName('insertcqpchantier');
  $this->post('/inserttablecqp',               ForceController::class. ':inserttablecqp')         ->setName('inserttablecqp');
  $this->post('/insertpmsmp',                  ForceController::class. ':insertpmsmp')            ->setName('insertpmsmp');
  $this->post('/insertprolpmsmp',              ForceController::class. ':insertprolpmsmp')        ->setName('insertprolpmsmp');
  $this->post('/docsalarie',                   ForceController::class. ':docsalarie')             ->setName('docsalarie');
  $this->post('/okdelsalarie',                 ForceController::class. ':okdelsalarie')           ->setName('okdelsalarie');
  $this->get('/search',                        ForceController::class. ':Requete')                ->setName('executionrecherche');
  $this->get('/modifsalarie/{idsalarie}',      ForceController::class. ':modifsalarie')           ->setName('modifsalarie');
  $this->get('/modifsalarie',                  ForceController::class. ':modifsalarie')           ->setName('modifsalarie');
  $this->get('/editsalarie/{idsalarie}',       ForceController::class. ':editsalarie')            ->setName('editsalarie');
  $this->get('/editsalarie',                   ForceController::class. ':editsalarie')            ->setName('editsalarie');
  $this->get('/sortiesalarie/{idsalarie}',     ForceController::class. ':sortiesalarie')          ->setName('sortiesalarie');
  $this->get('/delsalarie/{idsalarie}',        ForceController::class. ':delsalarie')             ->setName('delsalarie');
  $this->get('/sortiesalarie',                 ForceController::class. ':sortiesalarie')          ->setName('sortiesalarie');
  $this->get('/newsalarie',                    ForceController::class. ':newsalarie')             ->setName('newsalarie');
  $this->get('/newchantier',                   ForceController::class. ':newchantier')            ->setName('newchantier');
  $this->get('/newdoc',                        ForceController::class. ':newdoc')                 ->setName('newdoc');
  $this->get('/newpres',                       ForceController::class. ':newpres')                ->setName('newpres');
  $this->get('/newpermis',                     ForceController::class. ':newpermis')              ->setName('newpermis');
  $this->get('/newsortie',                     ForceController::class. ':newsortie')              ->setName('newsortie');
  $this->get('/newdemarche',                   ForceController::class. ':newdemarche')            ->setName('newdemarche');
  $this->get('/newidentite',                   ForceController::class. ':newidentite')            ->setName('newidentite');
  $this->get('/newmotif',                      ForceController::class. ':newmotif')               ->setName('newmotif');
  $this->get('/newdetailsortie',               ForceController::class. ':newdetailsortie')        ->setName('newdetailsortie');
  $this->get('/newdetaildemarche',             ForceController::class. ':newdetaildemarche')      ->setName('newdetaildemarche');
  $this->get('/newdetailtypedemarche',         ForceController::class. ':newdetailtypedemarche')  ->setName('newdetailtypedemarche');
  $this->get('/newformation',                  ForceController::class. ':newformation')           ->setName('newformation');
  $this->get('/newlocomotion',                 ForceController::class. ':newlocomotion')          ->setName('newlocomotion');
  $this->get('/newetudes',                     ForceController::class. ':newetudes')              ->setName('newetudes');
  $this->get('/newsituation',                  ForceController::class. ':newsituation')           ->setName('newsituation');
  $this->get('/newressources',                 ForceController::class. ':newressources')          ->setName('newressources');
  $this->get('/renouvellement',                ForceController::class. ':renouvellement')         ->setName('renouvellement');
  $this->get('/stat',                          ForceController::class. ':stat')                   ->setName('stat');
  $this->get('/DocList',                       ForceController::class.':DocList')                 ->setName('DocList');
  $this->get('/permis',                        ForceController::class.':permis')                  ->setName('permis');
  $this->get('/formation',                     ForceController::class.':formation')               ->setName('formation');
  $this->get('/locomotion',                    ForceController::class.':locomotion')              ->setName('locomotion');
  $this->get('/etudes',                        ForceController::class.':etudes')                  ->setName('etudes');
  $this->get('/document',                      ForceController::class. ':document')               ->setName('document');
  $this->get('/cqpchantier/{idlieu}',          ForceController::class. ':cqpchantier')            ->setName('cqpchantier');
  $this->get('/sstchantier/{idlieu}',          ForceController::class. ':sstchantier')            ->setName('sstchantier');
  $this->get('/statistique',                   ForceController::class. ':statistique')            ->setName('statistique');
  $this->get('/sstchantier',                   ForceController::class. ':sstchantier')            ->setName('sstchantier');

})->add($container->get('authadmin'));

// $app->get('/', HomeController::class. ':getHome')->setName('home');
// Exemple pour le RouterJS
// $app->get('/hello/{name}', HomeController::class. ':getHome')->setName('hello');
?>
