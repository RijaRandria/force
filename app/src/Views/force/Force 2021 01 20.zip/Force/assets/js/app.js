// Besoin de jQuery ? Installer avec "npm i --save jquery", puis décommenté la ligne d'import
// import $ from "jquery";

import { log } from '@js/log.js'
log('Hello World!')
