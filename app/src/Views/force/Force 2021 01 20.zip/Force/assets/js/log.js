export function log (value) {
  console.log(value)
}
